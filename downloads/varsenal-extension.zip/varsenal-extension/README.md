# Varsenal Chrome Extension

This tiny Chrome extension changes visible page text from:

Arsenal → Varsenal

## Install locally

1. Download and unzip this folder.
2. Open Chrome on desktop.
3. Go to `chrome://extensions`.
4. Turn on **Developer mode**.
5. Click **Load unpacked**.
6. Select the unzipped `varsenal-extension` folder.
7. Open or refresh any web page containing the word Arsenal.

## Notes

- This is a local/dev extension unless you publish it to the Chrome Web Store.
- It does not change URLs, form fields, scripts, or editable text areas.
- It watches dynamic pages too, so it should work on feeds and live pages after content loads.